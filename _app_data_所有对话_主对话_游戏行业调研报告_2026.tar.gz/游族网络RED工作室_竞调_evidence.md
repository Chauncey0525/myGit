# 游族网络R.E.D发行工作室调研 - 结构化证据底稿

> 生成时间：2026-07-01
> 调研目标：游族网络股份有限公司（002174.SZ）及R.E.D发行工作室
> 框架：company-competitor-research 四维框架

---

## 证据记录规范

每条证据使用7字段格式：

```
Claim: [具体事实陈述]
Source: [来源名]
URL: [来源URL]
Date: [发布日期]
Excerpt: [逐字原文摘录]
Context: [影响理解的上下文]
Confidence: [HIGH/MEDIUM/LOW]
```

---

## 维度一：基本盘与商业模式

### 探索轮 - 预热搜索



---

## 维度一：基本盘与商业模式（证据记录）

### 证据1.1：公司基本信息
Claim: 游族网络成立于2009年，是一家全球化的互动娱乐科技公司，2014年5月借壳梅花伞登陆A股主板（股票代码002174）
Source: 游族官网
URL: https://www.yoozoo.com/en/about
Date: N/A
Excerpt: 游族网络成立于2009年，是一家全球化的互动娱乐科技公司...总部位于上海，并在德国、新加坡、日本等多个国家设有分支机构。2014年5月，游族网络正式登陆中国A股主板。
Context: 公司主营业务为网络游戏研发、发行及运营
Confidence: HIGH

### 证据1.2：2025年财务表现
Claim: 2025年游族网络营收14.02亿元，海外收入占比66.5%创历史新高
Source: 每日经济新闻
URL: https://m.nbd.com.cn/articles/2026-04-30/4376556.html
Date: 2026-05-01
Excerpt: 2025年公司营收14.02亿元，海外收入占比达66.5%创历史新高；2026年一季度归母净利润同比大增320%
Context: 海外收入连续11年领先，AI赋能驱动盈利能力提升
Confidence: HIGH

### 证据1.3：股权结构与管理层
Claim: 游族网络目前处于无控股股东、无实际控制人状态，第一大股东为上海加游（持股10.95%），董事长为宛正
Source: 同花顺、南方都市报
URL: https://profile.10jqka.com.cn/002174/company/
Date: 2026-06-26
Excerpt: 控股股东：无控股股东；实际控制人：无实际控制人...董事长宛正，1984年出生，毕业于东华大学拉萨尔国际设计学院
Context: 2023年林奇家族退出，宛正通过上海加游入主
Confidence: HIGH

### 证据1.4：林奇事件后续影响
Claim: 2020年12月25日创始人林奇因许垚投毒离世，游族网络经历股权混战和业绩动荡
Source: 腾讯新闻、澎湃新闻
URL: https://news.qq.com/rain/a/20240322A04DNR00
Date: 2024-03-22
Excerpt: 2020年12月25日，39岁的游族网络创始人林奇因核心高管许垚投毒离世...2023年3月，许芬芬以10.95亿元将11.72%股份转让给上海加游
Context: 许垚于2026年5月被执行死刑
Confidence: HIGH

### 证据1.5：财务风险-商誉减值
Claim: 游族网络2024年计提资产减值7,309万元，其中商誉减值161.66万元
Source: 游族网络公告
URL: https://disc.static.szse.cn/disc/disk03/finalpage/2025-04-25/9378459f-79f2-426e-85fe-fe5dff68e84b.PDF
Date: 2025-04-25
Excerpt: 2024年度计提信用减值准备和资产减值准备，计提金额合计为7,309.13万元...商誉减值损失161.66万元
Context: 公司商誉/净资产比值持续增长，近三期分别为4.6%、4.8%、4.9%
Confidence: HIGH

---

## 维度二：核心产品与杀手级卖点（证据记录）

### 证据2.1：R.E.D发行工作室介绍
Claim: R.E.D发行工作室是游族全球发行中心旗下团队，负责《绯色回响》《圣斗士星矢觉醒》等产品全球发行，实现多款产品单区域月流水破千万美金
Source: GameRes游资网
URL: https://www.gameres.com/897646.html
Date: 2022-10-28
Excerpt: 《绯红神约》由游族全球发行中心的R.E.D发行工作室负责全球发行工作，该工作室是一个面向全球市场进行精品化游戏发行的团队，此前曾在海外成功发行《圣斗士星矢觉醒：十二宫骑士》等多个爆款产品，实现多款产品单区域月流水破千万美金的成绩
Context: R.E.D工作室是游族海外发行的核心力量
Confidence: HIGH

### 证据2.2：核心产品线
Claim: 游族核心产品包括"少年"系列卡牌（《少年三国志》《少年三国志2》《少年西游记2》）、SLG产品（《战火与永恒》《权力的游戏凛冬将至》）
Source: 游族2025年年报
URL: https://static.cninfo.com.cn/finalpage/2026-04-29/1225235206.PDF
Date: 2026-04-29
Excerpt: 公司成功推出以"少年"系列IP为代表的经典自研卡牌手游《少年三国志》《少年三国志2》《少年三国志:零》《少年西游记》《少年西游记2》，以及自研SLG游戏《GameofThronesWinterisComing》PC、《InfinityKingdom》等长周期产品
Context: 聚焦"卡牌+"和"SLG+"双赛道
Confidence: HIGH

### 证据2.3：《战火与永恒》表现
Claim: 《战火与永恒》2025年上半年流水同比增长225%，成为全球化发行标杆产品
Source: 上海证券报
URL: http://www.cnstock.com/commonDetail/497203
Date: 2025-08-25
Excerpt: 旗下多款全球化产品表现亮眼，其中《战火与永恒》流水同比劲增225%...成为全球化发行标杆产品
Context: SLG产品逆势增长，验证区域化运营能力
Confidence: HIGH

### 证据2.4：《少年三国志》长线运营
Claim: 《少年三国志》自2015年上线至今运营超10年，2025年上半年小程序版本流水超5000万元
Source: 东方财富网
URL: https://caifuhao.eastmoney.com/news/20250827134523975412040
Date: 2025-08-27
Excerpt: 《少年三国志·怀旧版》在报告期内录得流水超5000万元...《Infinity Kingdom》在报告期内逆势上涨，同比增长了225%
Context: 小程序渠道成为存量IP新增长点
Confidence: HIGH

### 证据2.5：三体游戏进展
Claim: 《我的三体：2277》定位为"AI原生游戏"，预计2026年上半年上线
Source: 36氪
URL: http://m.toutiao.com/group/7531686554691994163/
Date: 2025-07-27
Excerpt: 游族网络正在研发的《三体》正版IP游戏《我的三体:2277》，该游戏是一款"AI原生游戏"，其核心特点在于玩家UGC功能
Context: 三体游戏因许垚事件停滞多年，2020年底重启后研发进展缓慢
Confidence: HIGH

---

## 维度三：营销与流量操盘策略（证据记录）

### 证据3.1：海外发行策略
Claim: 游族坚持"因地制宜"的精细化运营，针对不同市场定制差异化发行策略
Source: 游族官网
URL: https://www.yoozoo.com/enterprise/7019519.html
Date: 2024-02-22
Excerpt: 坚持"差异化"定制不同市场的发行策略，根据当地用户特点进行本地化精细运营，针对不同市场的文化特点、用户特性打造专属活动，并制作定制化宣发内容
Context: 全球化发行能力是核心竞争力
Confidence: HIGH

### 证据3.2：AI赋能发行
Claim: 游族通过AI技术实现"一个版本、全球发行"的经营效率
Source: 21世纪经济报道
URL: http://m.toutiao.com/group/7497942185980068386/
Date: 2025-04-27
Excerpt: 基于AI技术赋能，游族网络已构建覆盖从版本发布、平台接入、市场推广、数据分析、用户管理等发行全环节的AI工具平台，有效提升了"一个版本、全球发行"的经营效率
Context: AI投放引擎优化广告投放策略
Confidence: HIGH

### 证据3.3：KOL营销案例
Claim: 《绯色回响》韩国上线时邀请头部游戏KOL和KOC进行精准营销
Source: 21世纪经济报道
URL: http://m.toutiao.com/group/7497942185980068386/
Date: 2025-04-27
Excerpt: 邀请了韩国头部游戏Kol和垂直赛道产品的Koc，针对用户进行直播和视频素材的精准营销
Context: 社群运营与KOL合作是日韩市场重要打法
Confidence: HIGH

### 证据3.4：本地化策略案例
Claim: 《少年三国志2》欧美上线时邀请当地知名作家进行风格化调整
Source: 经济观察报
URL: http://m.toutiao.com/group/7454103390885265956/
Date: 2024-12-30
Excerpt: 《少年三国志2》在欧美市场上线后，我们邀请了当地知名的作家，了解用户对东方文学的需求...这也是我们正在进行的尝试，将游戏与中国文化相融合，同时融入一些与欧美用户相适配的东西
Context: 欧美市场需要对中国文化进行本地化改编
Confidence: MEDIUM

---

## 维度四：真实负面评价与管理风险（证据记录）

### 证据4.1：用户投诉-鬼服问题
Claim: 有用户投诉《少年三国志》VIP10用户充值3万余元后因区服鬼服无法正常游戏，7年来问题未解决
Source: 黑猫投诉
URL: https://tousu.sina.cn/complaint/view/17394863863
Date: 2026-03-22
Excerpt: 本人是《少年三国志》VIP10用户，累计充值3万余元...本人因所在区服无活跃玩家（鬼服）无法正常进行核心玩法，被迫退游...本人通过游戏内公示的VIP专线进行反馈，要求合服或转服，三次被明确拒绝
Context: 高价值用户服务体验差，VIP专线形同虚设
Confidence: HIGH [NEGATIVE]

### 证据4.2：用户投诉-退款纠纷
Claim: 有用户在《绯色回响》充值后因家人手术申请退款被拒
Source: 黑猫投诉
URL: https://fj.tousu.sina.cn/company/view/?couid=2152406592
Date: 2026-04-25
Excerpt: 我4月份在游族公司下的绯色回响游戏里充值，妹妹肿瘤做手术没钱了，想退款吃点好的
Context: 退款政策执行僵化
Confidence: MEDIUM [NEGATIVE]

### 证据4.3：员工评价-裁员应届生
Claim: 2023年游族"一刀切"裁掉所有应届校招生，超过200人受影响
Source: 时代财经
URL: http://m.toutiao.com/group/7249749226945528381/
Date: 2023-06-28
Excerpt: 上午通知，下午就让我走人，除了5000元的赔偿之外，什么都没有...在我离开的时候，校招群里就只剩50多人了
Context: 新实控人宛正进场后大规模裁员
Confidence: HIGH [NEGATIVE]

### 证据4.4：知乎员工吐槽
Claim: 知乎上"你为什么从游族离职"问题收到116条回答，主要吐槽工资低、加班多、管理混乱
Source: 36氪
URL: https://www.36kr.com/p/1029586014029833
Date: 2020-12-28
Excerpt: 一位匿名用户的答案提到：员工工具化、管理无脑化、加班常态化。另一位匿名用户的答案是：工资极低、付出与回报不成比例；文化极其糟糕；管理混乱；加班极多
Context: 历史员工评价，存在改善可能
Confidence: MEDIUM [NEGATIVE]

### 证据4.5：监管处罚
Claim: 2021年游族网络因未及时披露业绩修正信息收到福建证监局警示函
Source: 证监会福建监管局
URL: http://www.csrc.gov.cn/fujian/c104054/c1658013/content.shtml
Date: 2021-12-21
Excerpt: 公司存在未及时按规定披露信息的问题...将2020年度预计净利润向下修正为-18,771.58万元...盈亏性质发生变化且差异金额较大
Context: 信息披露违规被监管警示
Confidence: HIGH [NEGATIVE]

### 证据4.6：财务风险-盈利波动
Claim: 游族网络净利润波动剧烈，2022年亏损6.35亿，2023年盈利0.91亿，2024年亏损3.86亿
Source: 新浪财经
URL: https://finance.sina.com.cn/wm/2026-05-27/doc-inhzkfvc1452790.shtml
Date: 2026-05-27
Excerpt: 2020年：净亏损1.88亿元；2021年：净利润1.68亿元；2022年：净亏损6.35亿元；2023年：净利润；2024年：净亏损3.86亿元。盈亏交替出现，且幅度较大
Context: 盈利稳定性差，主营业务盈利能力待验证
Confidence: HIGH [NEGATIVE]

---

## 综合对比（证据记录）

### 证据5.1：出海排名对比
Claim: 2025年中国手游出海收入TOP10中，点点互动超越腾讯位列第一，游族未入榜
Source: Sensor Tower / TapTap
URL: https://www.taptap.cn/moment/760625050649890608
Date: 2026-01-14
Excerpt: 点点互动以87%的收入增幅跃居亚军...《Whiteout Survival》连续24个月蝉联出海收入冠军
Context: 游族出海收入规模不及头部厂商
Confidence: HIGH

### 证据5.2：与三七互娱对比
Claim: 三七互娱2024年营收规模约为游族的11倍（160亿 vs 14亿），SLG品类全球竞争力领先
Source: 晓经济
URL: https://www.xiaojingji.com/stock/one/competitor?code=002174
Date: N/A
Excerpt: 三七互娱...营收规模（2023年约160亿元）显著高于游族（约20亿元）
Context: 体量差距明显
Confidence: MEDIUM

### 证据5.3：出海厂商竞争格局
Claim: 中国出海厂商第一梯队为腾讯、点点互动、米哈游、网易，游族处于第二梯队
Source: 新京报
URL: https://m.bjnews.com.cn/detail/1779074089129346.html
Date: 2026-05-18
Excerpt: 点点互动、腾讯游戏、米哈游、三七互娱、莉莉丝游戏稳居第一梯队...游族需在区域市场争夺份额
Context: 游族出海实力获认可但与头部差距较大
Confidence: MEDIUM
