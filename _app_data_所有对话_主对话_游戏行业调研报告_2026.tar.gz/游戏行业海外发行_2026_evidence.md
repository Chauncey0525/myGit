# 游戏行业海外发行_2026_evidence

## 证据结构规范
每条证据遵循7字段格式：
- Claim: [具体事实陈述]
- Source: [来源名称]
- URL: [深链URL]
- Date: [发布日期 YYYY-MM]
- Excerpt: [原文逐字摘录]
- Context: [影响解读的上下文]
- Confidence: [HIGH/MEDIUM/LOW]

---

## 一、全球游戏市场规模与CAGR

### 证据1：全球游戏市场规模（2025-2026）
**Claim**: 2025年全球游戏市场规模约为1888-1890亿美元，预计2026年达到约2000亿美元，同比增长约6%
**Source**: Newzoo、Kevuru Games综合分析
**URL**: https://kevurugames.com/blog/game-development-industry-statistics-market-size-revenue-and-key-trends/
**Date**: 2026-05
**Excerpt**: The global games market in 2026 is expected to move slightly above $200 billion. The most consistent baseline still comes from Newzoo report, with $188.8 billion of revenue for 2025.
**Context**: 全球游戏市场经历疫情后的调整期后重新恢复增长，移动端仍是最大贡献者
**Confidence**: HIGH

### 证据2：移动游戏市场规模
**Claim**: 2025年全球移动游戏市场规模接近820亿美元，占整体游戏市场约49%
**Source**: AppMagic、Sensor Tower
**URL**: https://post.m.smzdm.com/p/axkg50vw/
**Date**: 2025-12
**Excerpt**: 2025年全球移动游戏应用内购买市场规模接近820亿美元，其中直接面向消费者（DTC）模式已占1133亿市场的15%
**Context**: 移动端主导地位稳固，F2P+IAP模式仍是主流变现方式
**Confidence**: HIGH

### 证据3：中国游戏市场规模（2025-2026）
**Claim**: 2025年中国游戏市场实际销售收入约3417亿元，同比增长约7.5%；2026年预计达到3680亿元
**Source**: 伽马数据（CNG）
**URL**: https://www.docin.com/touch_new/preview_new.do?id=4933991434
**Date**: 2026-02
**Excerpt**: 2026年中国游戏市场实际销售收入预计达到3,680亿元人民币，同比增长率稳定在7.8%左右
**Context**: 中国市场全球占比约25-30%，是仅次于美国的第二大单一国家市场
**Confidence**: HIGH

### 证据4：全球游戏市场CAGR预测
**Claim**: 2025-2032年全球游戏市场CAGR预计约为10.07%，2032年达到5424亿美元
**Source**: 360iResearch
**URL**: https://www.giiresearch.com/report/ires1993120-gaming-market-by-platform-business-model-genre.html
**Date**: 2026-03
**Excerpt**: The Gaming Market was valued at USD 277.05 billion in 2025 and is projected to grow to USD 304.73 billion in 2026, with a CAGR of 10.07%, reaching USD 542.40 billion by 2032.
**Context**: 市场增长主要由AI技术、云游戏、新兴市场驱动
**Confidence**: MEDIUM

### 证据5：中国自研游戏海外收入
**Claim**: 2025年中国自研游戏海外市场实际销售收入达204.55亿美元，同比增长10.23%，连续六年突破千亿元人民币
**Source**: 中国音数协游戏工委、伽马数据
**URL**: https://m.itouchtv.cn/article/680964f4a1d6e0bc28b89e7b3dcd7873
**Date**: 2026-04
**Excerpt**: 2025年，中国游戏出海延续强劲复苏态势，全年海外市场实际销售收入突破204.55亿美元，同比增长10.23%，连续六年突破千亿元人民币大关
**Context**: 海外市场成为中国游戏企业的核心增长引擎
**Confidence**: HIGH

---

## 二、区域市场分析

### 证据6：美国市场数据
**Claim**: 美国是中国游戏出海最大单一市场，2025年海外收入占比32.31%，核心特征是SLG/消除类强势，混合变现ROAS达146%
**Source**: 伽马数据、时代财经
**URL**: http://m.toutiao.com/group/7629405599939215906/
**Date**: 2026-04
**Excerpt**: 美国以32.31%的收入占比居首，核心特征是SLG/消除类强势，混合变现ROAS达146%
**Context**: 美国市场成熟度高、付费能力强但获客成本也较高
**Confidence**: HIGH

### 证据7：日本市场数据
**Claim**: 日本是中国游戏出海第二大市场，2025年海外收入占比16.35%，二次元/RPG高度契合
**Source**: 伽马数据
**URL**: https://blog.csdn.net/u012565335/article/details/151574265
**Date**: 2026-04
**Excerpt**: 2025年，日本市场规模遭遇连续3年下行挑战，2025年降幅超5%，但二次元/RPG品类仍保持优势
**Context**: 日本市场整体收缩，但中国二次元游戏表现突出
**Confidence**: HIGH

### 证据8：韩国市场数据
**Claim**: 韩国市场2025年海外收入占比9.15%，MMORPG受欢迎，增速最快
**Source**: 伽马数据
**URL**: https://blog.csdn.net/u012565335/article/details/151574265
**Date**: 2026-04
**Excerpt**: 韩国移动游戏市场规模约人民币311.8亿元，同比上升6.6%；新品迭代快，本土IP重制成为增长动力
**Context**: 韩国市场成熟，迭代节奏快，竞争激烈
**Confidence**: HIGH

### 证据9：中东市场规模
**Claim**: 2024年中东MENA-3地区游戏市场规模达20亿美元，预计2028年达到27.23亿美元，CAGR 7.2%
**Source**: Niko Partners、Xsolla
**URL**: https://nikopartners.com/wp-content/uploads/2025/03/Xsolla-Niko-Partners-What-Does-the-Monetization-Landscape-Look-Like-for-Video-Games-in-MENA.pdf
**Date**: 2025-03
**Excerpt**: In 2024, the MENA-3 region generated $2 billion in player spending, a 4% YoY increase. By 2028, the region is projected to surpass $2.7 billion in spending, growing at a 5-year CAGR of 7.2%.
**Context**: 沙特、阿联酋ARPU极高，是全球最高付费市场之一
**Confidence**: HIGH

### 证据10：中东沙特市场
**Claim**: 沙特以10亿美元游戏年支出位居中东榜首，人均消费393美元为区域最高
**Source**: Khaleej Times、Statista
**URL**: https://www.khaleejtimes.com/business/tech/uae-gaming-market-growth-video-games-dominate-digital-spending
**Date**: 2026-02
**Excerpt**: Saudi Arabia remains the largest gaming market by value, with spending approaching $1 billion and accounting for roughly 69% of total digital media expenditure. The Kingdom also leads the region in user spending, with an annual average of $393 per player.
**Context**: 沙特2030愿景推动游戏产业快速发展
**Confidence**: HIGH

### 证据11：东南亚市场
**Claim**: 东南亚是中国游戏出海重要区域，2025年海外收入占比7.62%，付费心智快速成熟
**Source**: 中国音数协
**URL**: http://m.toutiao.com/group/7629405599939215906/
**Date**: 2026-04
**Excerpt**: 东南亚占比7.62%，付费心智快速成熟；印度尼西亚、越南和菲律宾三国贡献了超过60%的区域营收
**Context**: 人口红利大、移动互联网普及率高、用户年轻
**Confidence**: HIGH

### 证据12：拉美市场规模
**Claim**: 2024年拉美游戏市场规模约70亿美元，预计2025年突破100亿美元，CAGR约14%
**Source**: Inter-American Development Bank
**URL**: https://www.iadb.org/document.cfm?id=EZIDB0000474-1641826802-22
**Date**: 2025
**Excerpt**: 拉丁美洲游戏市场在2022年的营收规模达到了约65亿美元，较2017年增长了近150%，预计到2025年市场规模将突破100亿美元
**Context**: 巴西主导拉美市场，占区域总市场的35%
**Confidence**: MEDIUM

### 证据13：欧洲市场
**Claim**: 2025年欧洲整体移动游戏市场规模达761亿元，同比增长9.8%；德、英、法三国合计占比8.78%
**Source**: 伽马数据
**URL**: https://blog.csdn.net/u012565335/article/details/151574265
**Date**: 2026-04
**Excerpt**: 2025年，欧洲整体移动游戏市场规模达人民币761亿元，同比增长9.8%。长线产品表现不错，新品占比仅2%
**Context**: 欧洲是中国游戏出海重要区域，用户付费意愿高
**Confidence**: HIGH

---

## 三、产业链与利润分配

### 证据14：渠道分成比例
**Claim**: 苹果App Store和Google Play标准抽成30%，国内安卓渠道（硬核联盟）抽成高达50%
**Source**: 公开报道综合
**URL**: http://m.toutiao.com/group/7624239071291916800/
**Date**: 2026-04
**Excerpt**: 苹果App Store标准分成比例为30%，而在国内，硬核联盟长期执行着游戏厂商与渠道5:5的分成规则
**Context**: 渠道分成是游戏厂商最大刚性支出之一
**Confidence**: HIGH

### 证据15：Google Play降低抽成
**Claim**: 2026年3月谷歌宣布调整Google Play抽成比例至20%或更低，并向第三方支付系统敞开大门
**Source**: 东方财富
**URL**: https://caifuhao.eastmoney.com/news/20260305233354067359160
**Date**: 2026-03
**Excerpt**: 谷歌此次调整的核心逻辑，在于打破封闭生态的垄断壁垒。抽成比例下调直接降低渠道成本
**Context**: 谷歌政策调整为出海游戏厂商带来利润增厚机会
**Confidence**: HIGH

### 证据16：玩家充值100美元后研发商到手金额
**Claim**: 玩家充值100美元，经过渠道抽成（30美元）、发行商分成（14美元）、买量成本（约15美元）、税费等，最终研发商到手可能不足30美元
**Source**: 增长黑盒
**URL**: https://growthbox.net/china-game-overseas-cost-revenue-payment/
**Date**: 2025-03
**Excerpt**: 玩家充值100美元，经渠道抽成、发行商分成、买量成本、税费、汇损等层层扣除后，研发商到手可能不足30美元
**Context**: 出海利润被多重中间环节摊薄
**Confidence**: HIGH

### 证据17：产业链结构
**Claim**: 游戏产业链分为上游（研发）、中游（发行与运营）、下游（分发）三大核心层级
**Source**: 网易财经
**URL**: http://m.163.com/dy/article/K90O1DTQ05568W0A.html
**Date**: 2025-09
**Excerpt**: 游戏产业链可分为上游（研发）、中游（发行与运营）、下游（分发）三大核心层级
**Context**: 用户处于中游位置（游戏发行与运营）
**Confidence**: HIGH

---

## 四、头部出海公司分析

### 证据18：腾讯游戏出海
**Claim**: 腾讯《PUBG MOBILE》2025年海外收入27.57亿元，常青榜TOP2；上线7年依然稳居全球射击手游榜首
**Source**: 时代财经
**URL**: http://m.toutiao.com/group/7629405599939215906/
**Date**: 2026-04
**Excerpt**: 《PUBG MOBILE》2025年海外收入27.57亿元，常青榜TOP2，2026年Q1收入7.23亿元，上线7年依然稳居全球射击手游榜首
**Context**: 腾讯是出海收入规模最大的中国游戏公司
**Confidence**: HIGH

### 证据19：米哈游出海
**Claim**: 米哈游《原神》2025年海外收入22.1亿元，《崩坏：星穹铁道》2025年海外收入31.29亿元
**Source**: 36氪、时代财经
**URL**: https://36kr.com/p/3644856280764289
**Date**: 2026-01
**Excerpt**: 米哈游是上榜游戏最多的发行商，旗下《崩坏：星穹铁道》《原神》《绝区零》均入围年度出海收入TOP30
**Context**: 米哈游凭借原创IP实现全球化突破
**Confidence**: HIGH

### 证据20：点点互动出海
**Claim**: 点点互动《Whiteout Survival》2025年海外收入75.36亿元（10.79亿美元），累计全球收入突破28亿美元
**Source**: Sensor Tower、36氪
**URL**: https://36kr.com/p/3644856280764289
**Date**: 2026-01
**Excerpt**: 《Whiteout Survival》2025年海外收入显著上涨32%，超过16.5亿美元，蝉联2025年出海手游收入榜冠军
**Context**: 点点互动是出海收入增长最快的中国厂商之一
**Confidence**: HIGH

### 证据21：三七互娱出海
**Claim**: 三七互娱2025年境外收入占比33.70%，《Puzzles & Survival》累计流水超过150亿元
**Source**: 央广网
**URL**: http://tech.cnr.cn/techph/20260416/t20260416_527587407.shtml
**Date**: 2026-04
**Excerpt**: 2025年公司实现境外营业收入53.81亿元，占公司总营业收入比重33.70%。《Puzzles & Survival》截至2025年底全球累计流水已超过150亿元
**Context**: 三七互娱海外收入占比超过三分之一
**Confidence**: HIGH

### 证据22：莉莉丝游戏
**Claim**: 莉莉丝《万国觉醒》《剑与远征》通过深度本地化叙事与美术风格调整实现长线运营
**Source**: 行业报告
**URL**: https://m.book118.com/html/2025/1020/5232331004013001.shtm
**Date**: 2025-10
**Excerpt**: 莉莉丝的《万国觉醒》《剑与远征》则通过深度本地化叙事与美术风格调整，实现长线运营
**Context**: 莉莉丝是SLG出海的头部厂商
**Confidence**: MEDIUM

### 证据23：沐瞳科技
**Claim**: 沐瞳科技《Mobile Legends: Bang Bang》在东南亚月活超1.1亿，沙特Savvy Games Group以超60亿美元收购
**Source**: 新浪财经
**URL**: https://news.sina.cn/bignews/insight/2026-03-21/detail-inhrswyi6326677.d.html
**Date**: 2026-03
**Excerpt**: 《MLBB》在东南亚月活超1.1亿，印尼、菲律宾渗透率超25%。沙特Savvy Games Group以超60亿美元完成收购
**Context**: 沐瞳是MOBA出海标杆，被沙特主权基金收购
**Confidence**: HIGH

---

## 五、商业模式分析

### 证据24：F2P/IAP主导地位
**Claim**: F2P/IAP模式预计在2026年占据57%的市场份额，是最主流的变现模式
**Source**: Fact MR
**URL**: https://www.factmr.com/report/124/video-games-market
**Date**: 2026-03
**Excerpt**: F2P (Free-to-Play)/IAP (In-App Purchases) is expected to dominate the market, accounting for 57% of the market share in 2026
**Context**: 免费+内购模式在移动端占据绝对主导
**Confidence**: HIGH

### 证据25：混合变现趋势
**Claim**: 混合变现模式（IAA+IAP）正成为主流，占比从2023年Q3的25%攀升至2024年Q3的29%
**Source**: 增长黑盒
**URL**: https://growthbox.net/china-game-overseas-cost-revenue-payment/
**Date**: 2025-03
**Excerpt**: 混合变现模式（IAA+IAP）正成为主流，占比从2023年Q3的25%攀升至2024年Q3的29%
**Context**: IAA收入同比增长60%，IAP收入同比增长50%
**Confidence**: HIGH

### 证据26：订阅制发展
**Claim**: 订阅服务在欧美市场扩展，PlayStation+订阅用户达5800万（2024年）
**Source**: 雪球
**URL**: https://xueqiu.com/8719413633/342525007
**Date**: 2025-07
**Excerpt**: Sony凭借PlayStation+订阅服务（2024年付费用户达5800万），构建"主机+游戏+影视"IP协同壁垒
**Context**: 订阅制在主机端表现较好，但移动端普及有限
**Confidence**: MEDIUM

### 证据27：买断制市场
**Claim**: 2025年国产买断制游戏全年销售额达31.6亿元，同比增长17%，创历史新高
**Source**: 什么值得买
**URL**: https://post.m.smzdm.com/p/axkg50vw/
**Date**: 2025-12
**Excerpt**: 从2025年的市场数据来看，国产买断制游戏全年销售额达31.6亿元，同比增长17%，创历史新高
**Context**: 买断制在中国市场仍有增长空间，主要集中在PC/主机端
**Confidence**: HIGH

---

## 六、政策合规风险

### 证据28：GDPR合规要求
**Claim**: GDPR最高罚款可达全球年营业额的4%或2000万欧元（取较高者）
**Source**: 声网
**URL**: https://www.shengwang.cn/info/39771.html
**Date**: 2025-09
**Excerpt**: 处罚力度：最高可达全球年营业额的4%或2000万欧元（取较高者）
**Context**: GDPR是进入欧洲市场的硬性门槛
**Confidence**: HIGH

### 证据29：CCPA/CPRA合规
**Claim**: CCPA违规罚款2500至7500美元不等，强调用户"选择退出权"
**Source**: 声网
**URL**: https://www.shengwang.cn/info/39771.html
**Date**: 2025-09
**Excerpt**: 处罚力度：每次违规罚款2500美元至7500美元不等
**Context**: 美国各州隐私法日益严格，加州是重点合规区域
**Confidence**: HIGH

### 证据30：中国版号政策
**Claim**: 2025年共计有1729款手游获得版号，相较于2024年的1368款整体增加了26.4%
**Source**: 艾瑞咨询
**URL**: https://pdf.dfcfw.com/pdf/H3_AP202604241821576014_1.pdf
**Date**: 2026-04
**Excerpt**: 2025年共计有1729款手游获得版号，相较于2024年的1368款整体增加了26.4%，手游仍是过审游戏中最高的类型
**Context**: 中国游戏监管政策全面回暖，版号发放常态化
**Confidence**: HIGH

### 证据31：中东文化合规
**Claim**: 中东市场需规避猪肉、酒精、血液、十字架等元素，斋月期间运营策略需调整
**Source**: 大数跨境
**URL**: https://m.sohu.com/a/913945260_121478199/
**Date**: 2025-07
**Excerpt**: 尽管中东用户逐步接轨全球化主流游戏，但宗教文化、支付习惯等特征依然显著。在内容上，需规避猪肉、酒精、血液、十字架等元素
**Context**: 中东市场本地化要求高，宗教文化限制多
**Confidence**: HIGH

---

## 七、技术趋势

### 证据32：AI辅助开发
**Claim**: 2026年Q1，AI辅助开发的游戏占新发布游戏的58%，开发周期缩短40%
**Source**: iBuidl
**URL**: https://ibuidl.org/blog/gaming-industry-trends-2026
**Date**: 2026-03
**Excerpt**: AI 辅助游戏开发占新游戏 58%，开发周期缩短 40%
**Context**: AI正在重塑游戏开发流程
**Confidence**: HIGH

### 证据33：AI游戏销量影响
**Claim**: 研究显示声明使用AI的Steam游戏，其首月评论数量平均比未使用AI的游戏低52.6%
**Source**: 澎湃新闻
**URL**: https://m.thepaper.cn/newsDetail_forward_33476470
**Date**: 2026-06
**Excerpt**: 在控制多项变量之后，声明使用AI的Steam游戏，其首月评论数量平均比未使用AI的游戏低52.6%
**Context**: 玩家对AI生成内容存在一定抵触情绪
**Confidence**: MEDIUM

### 证据34：云游戏增长
**Claim**: 2025年全球云游戏用户已超1.2亿，预计2030年将突破3亿
**Source**: 行业报告
**URL**: https://blog.csdn.net/u012565335/article/details/157102758
**Date**: 2026-06
**Excerpt**: 云游戏与AI驱动的个性化推荐技术正在重塑全球用户的游戏获取与消费方式，2025年全球云游戏用户已超1.2亿
**Context**: 云游戏降低硬件门槛，为出海提供新渠道
**Confidence**: MEDIUM

---

## 八、买量与广告投放

### 证据35：全球买量支出
**Claim**: 2023年全球游戏App用户获取支出达到290亿美元
**Source**: AppsFlyer
**URL**: https://growthbox.net/china-game-overseas-cost-revenue-payment/
**Date**: 2024
**Excerpt**: 2023年全球游戏App用户获取支出达到290亿美元，其中美国市场iOS花费66亿美元、Android花费55亿美元
**Context**: 买量成本是出海最大可变成本之一
**Confidence**: MEDIUM

### 证据36：2026年CPI上涨
**Claim**: 2026年全球移动游戏CPI同比上涨达30%，D1留存率约25-27%
**Source**: Mega Digital
**URL**: https://megadigital.ai/en/blog/mobile-game-user-acquisition/
**Date**: 2026-03
**Excerpt**: In 2026, global mobile game Cost Per Install (CPI) has surged by up to 30% YoY, while average Day-1 retention hovers perilously around 25-27%
**Context**: 获客成本持续上升，ROI压力增大
**Confidence**: HIGH

### 证据37：美国市场买量ROI
**Claim**: 美国市场SLG/消除类混合变现ROAS达146%
**Source**: 时代财经
**URL**: http://m.toutiao.com/group/7629405599939215906/
**Date**: 2026-04
**Excerpt**: 核心特征是SLG/消除类强势，混合变现ROAS达146%
**Context**: 美国市场虽然CPI高，但ROI也相对较高
**Confidence**: HIGH

---

## 九、行业趋势预测

### 证据38：2026年趋势
**Claim**: 2026年全球游戏市场预计达到约2000亿美元，移动端占比约50%，云游戏和AI是核心驱动力
**Source**: Newzoo、BCG综合
**URL**: https://blog.csdn.net/u012565335/article/details/157102758
**Date**: 2026-06
**Excerpt**: 移动（50%）：成熟市场增速放缓（1-2%），但亚太/新兴市场拉动。主机（28-30%，增长王）
**Context**: 市场进入平台期，增长依赖新兴市场和新技术
**Confidence**: HIGH

### 证据39：跨平台融合
**Claim**: 移动、PC、主机游戏互通成为趋势，同时与影视、动漫等娱乐形式融合
**Source**: 网易财经
**URL**: http://m.163.com/dy/article/K90O1DTQ05568W0A.html
**Date**: 2025-09
**Excerpt**: 跨平台融合：移动、PC、主机游戏互通成为趋势，同时与影视、动漫等娱乐形式融合
**Context**: 跨平台开发成为行业新标准
**Confidence**: HIGH

### 证据40：女性玩家增长
**Claim**: 中东市场女性玩家占比从2022年的32%上升至2025年的38%
**Source**: Niko Partners
**URL**: https://nikopartners.com/wp-content/uploads/2025/03/Xsolla-Niko-Partners-What-Does-the-Monetization-Landscape-Look-Like-for-Video-Games-in-MENA.pdf
**Date**: 2025-03
**Excerpt**: Once a male-dominated hobby, the broadening demographic underscores a growing need for developers to tailor both game design and monetization strategies to serve an increasingly diverse audience.
**Context**: 女性玩家群体扩大，带来新的市场机会
**Confidence**: MEDIUM
